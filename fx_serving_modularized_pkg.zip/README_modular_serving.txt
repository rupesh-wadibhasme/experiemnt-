
Modularized serving package for Databricks MLflow Model Serving

Files:
  - src/fx_serving/serving_utils/serializers.py
  - src/fx_serving/serving_security/safe_pickle.py
  - src/fx_serving/serving_core/artifacts.py
  - src/fx_serving/serving_domain/rules.py
  - pre_processing.py  (imports the above modules)

How to log with MLflow so Serving can import the package:
  mlflow.pyfunc.log_model(
      python_model=pre_processing.KerasAnomalyDetectorPyfunc(),
      name=artifact_path,
      conda_env=conda_env,
      artifacts=artifacts,
      code_paths=["src", "pre_processing.py"],
      registered_model_name=client_registered_model_full_name,
      model_config={"allowed_client": client},
  )
