from datetime import datetime, timezone
import json
import pandas as pd

def to_utc(x):
    """Convert epoch seconds / ISO string / datetime to tz-aware datetime (UTC) or None."""
    if x is None or x == '':
        return None
    if isinstance(x, (int, float)):
        return datetime.fromtimestamp(float(x), tz=timezone.utc)
    if isinstance(x, str):
        try:
            return datetime.fromisoformat(x.replace('Z', '+00:00'))
        except Exception:
            return None
    if isinstance(x, datetime):
        return x if x.tzinfo else x.replace(tzinfo=timezone.utc)
    return None

def to_json_safely(payload) -> str:
    """Safely JSON-serialize dict/str/DataFrame/ndarray/etc."""
    try:
        if isinstance(payload, pd.DataFrame):
            payload = json.loads(payload.to_json(orient="records"))
        return json.dumps(payload, default=str)
    except Exception:
        try:
            return json.dumps(str(payload))
        except Exception:
            return '"<unserializable>"'
