from dataclasses import dataclass
import pandas as pd
import tensorflow as tf
from fx_serving.serving_security.safe_pickle import safe_load

@dataclass
class AEArtifacts:
    model: tf.keras.Model
    scalers_dict: dict
    year_gap_data: pd.DataFrame

def load_artifacts_from_context(ctx) -> AEArtifacts:
    """Load Keras model and pickle artifacts from MLflow context."""
    model = tf.keras.models.load_model(ctx.artifacts["keras_autoencoder_path"])
    with open(ctx.artifacts["scalers_path"], "rb") as f:
        scalers_dict = safe_load(f)
    with open(ctx.artifacts["year_gap_data_path"], "rb") as f:
        year_gap_data = safe_load(f)
    return AEArtifacts(model=model, scalers_dict=scalers_dict, year_gap_data=year_gap_data)
