import pickle, builtins, importlib
from sklearn.preprocessing import MinMaxScaler

_ALLOWED_BUILTINS = {"dict","list","tuple","set","str","int","float","bool","bytes","slice"}
_ALLOW_MODULE_PREFIXES = ("sklearn", "numpy", "pandas")
_CLASS_REGISTRY = {("sklearn.preprocessing._data", "MinMaxScaler"): MinMaxScaler}

class RestrictedUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if module == "builtins" and name in _ALLOWED_BUILTINS:
            return getattr(builtins, name)
        if (module, name) in _CLASS_REGISTRY:
            return _CLASS_REGISTRY[(module, name)]
        if module.startswith(_ALLOW_MODULE_PREFIXES):
            mod = importlib.import_module(module)
            return getattr(mod, name)
        raise pickle.UnpicklingError(f"Forbidden global during unpickling: {module}.{name}")

    def persistent_load(self, pid):
        raise pickle.UnpicklingError("persistent IDs are forbidden")

def safe_load(file_obj):
    """Restricted pickle loader; raises on forbidden globals."""
    return RestrictedUnpickler(file_obj).load()
