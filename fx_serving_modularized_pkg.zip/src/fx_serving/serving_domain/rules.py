import pandas as pd

def compare_rows(df1: pd.DataFrame, df2: pd.DataFrame, cols=None) -> bool:
    cols = cols or ["BUnit","Cpty","BuyCurr","SellCurr","DealDate"]
    row = df2.iloc[0]
    return (df1[cols] == row[cols].values).all(axis=1).any()

def check_missing_group(data: pd.DataFrame, scalers: dict,
                        uniq_bu: set, uniq_cpty: set, uniq_pc: set):
    BU = data['BUnit'].values[0]; CPTY = data['Cpty'].values[0]; PC = data['PrimaryCurr'].values[0]
    group = (BU, CPTY, PC)
    if 'grouped_scalers' not in scalers or group not in scalers['grouped_scalers']:
        return 1, "This is the first FX contract with this busniness unit, counter party & primary currency"
    missing_BU = BU not in uniq_bu; missing_Cpty = CPTY not in uniq_cpty; missing_PC = PC not in uniq_pc
    if missing_BU and missing_Cpty and missing_PC:
        return 1, "This is the first FX contract with this busniness unit, counter party & primary currency"
    if missing_BU and missing_Cpty:
        return 1, "This is the first FX contract with this busniness unit & counterparty"
    if missing_Cpty and missing_PC:
        return 1, "This is the first FX contract with this counterparty and primary currency"
    if missing_BU and missing_PC:
        return 1, "This is the first FX contract with this busniness unit and primary currency "
    if missing_BU:   return 1, "This is the first FX contract with this business unit"
    if missing_Cpty: return 1, "This is the first FX contract with this counterparty"
    if missing_PC:   return 1, "This is the first FX contract with this primary currency."
    return 0, "No missing data"

def check_currency(data: pd.DataFrame, scalers: dict):
    CP = data['Cpty'].values[0]; buy = data['BuyCurr'].values[0]; sell = data['SellCurr'].values[0]
    if CP not in scalers['cpty_group']:
        return 1, "This is the first FX contract with this counterparty."
    trained = scalers['cpty_group'][CP]
    missing_buy  = buy  not in trained.get('buy', {})
    missing_sell = sell not in trained.get('sell', {})
    if missing_buy and missing_sell or missing_buy or missing_sell:
        return 1, "This currency pair has not been traded before for this counter party."
    return 0, "No new data"
